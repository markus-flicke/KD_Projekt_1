lower <-function (Str) {
# lower('str') converts any uppercase characters in the string str to the corresponding lowercase  characters and leaves all other characters unchanged. 
# lower(Str) when Str is array of strings, returns array the same size as A containing the result of applying lower to each string within A.

 tolower(Str)
} # end function  lower

