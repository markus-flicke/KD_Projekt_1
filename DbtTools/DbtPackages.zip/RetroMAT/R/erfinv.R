erfinv <- function(x){
# inverse error function
	qnorm((1 + x)/2)/sqrt(2)
}

