NoBlanks <- function (S) {
# NoBlanks(S)
# remove all blanks from string
#
# INPUT
# S              a String

# ALU

return(gsub(" ","",S))
 
}  #end   function   deblank 

