subplot <-
function (AnzZeilen,AnzSpalten,Index) par(mfrow=c(AnzZeilen,AnzSpalten))

