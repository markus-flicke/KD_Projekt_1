ylabel <-
function (Ylabel)
# works like MATHLAB's ylabel
{   title(ylab=    Ylabel)
}  #END FUNCTION

