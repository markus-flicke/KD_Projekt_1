xlabel <-
function (Xlabel)
# works like MATHLAB's xlabel
{   title(xlab=    Xlabel)
}  #END FUNCTION

