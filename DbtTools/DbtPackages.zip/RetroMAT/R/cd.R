cd <-function (Directory)
# cd(Directory)
# the same as setwd(Directory)
{
  setwd(Directory)
}  #END FUNCTION

