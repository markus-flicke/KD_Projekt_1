upper <-function (Str) {
# upper('str') converts any lowercase characters in the string str to the corresponding uppercase characters and leaves all other characters unchanged. 
# upper(Str) when Str is array of strings, returns array the same size as A containing the result of applying upper to each string within A.

 toupper(Str)
} # end function  upper

