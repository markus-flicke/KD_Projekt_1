 num2str <- function (Dummy) {
 return(paste(Dummy))

} # num2str <- function (Dummy) 

