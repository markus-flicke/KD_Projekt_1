gridOn <-
function ()
# works like MATHLAB's fuktion
{   
grid(lty='dashed',col='black')
}  #END FUNCTION

