str2num <- function (str) {
#   value <- str2num(str)
# str2num(str) converts the string str, which is an ASCII character representation of a numeric value, to numeric representation. 
# The str2num function can also convert string matrices.
   return(as.numeric(str))   ;
} # end function  str2num


