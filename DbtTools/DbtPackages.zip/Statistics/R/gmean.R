gmean <- function(x){

 return(m<-exp(mean(log(x))))

 }

