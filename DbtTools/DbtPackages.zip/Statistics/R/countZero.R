countZero <- function(x){

  return (sum(x==0,na.rm=TRUE)) 
  
}

