hmean <- function(x){   

 return (m=length(x)/sum(1/abs(x))) 

 }

