nanamad <- function(x){


 return (nanmad(x)*1.3) 

 }

