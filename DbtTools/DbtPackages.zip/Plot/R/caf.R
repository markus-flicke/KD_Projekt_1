caf <- function(){
    graphics.off()
}

