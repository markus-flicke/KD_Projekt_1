`RelativeNeighborhoodGraph` <-
function(X,Y,Delaunay,Gabriel){

# function [RNGraph,Gabriel,Delaunay] = RelativeNeighborhoodGraph(X,Y,Delaunay,Gabriel);
# % [RNGraph,Gabriel,Delaunay] = RelativeNeighborhoodGraph(X,Y,Delaunay,Gabriel);
# % Berechnung des Relative Neighborhood Graph RNG als Teilmenge des Gabriel Graphen GG
# %  
# % INPUT
# % [X(1:d),Y(1:d]                      Punktkoordinaten
# %
# % OPTIONAL
# % Delaunay(1:d,1:d)                   Adjazenzmatrix des Delaunay Graphen
# % Gabriel(1:d,1:d)                    Adjazenzmatrix des Gabriel  Graphen
# %
# % OUTPUT
# % RNGraph(1:d,1:d)                    Adjazenzmatrix des Relative Neighborhood Graphen
# % Delaunay(1:d,1:d)                   Adjazenzmatrix des Delaunay Graphen
# % Gabriel(1:d,1:d)                    Adjazenzmatrix des Gabriel  Graphen
# 
# % Naive Schnittkreis, vermutlich nicht sehr effizient
# % ALU 2008
# 
# if (nargin < 3) | (length(Delaunay)==0) % Delaunay Matrix ausrechnen
#     Delaunay  = DelaunayGraphMatrix(X,Y,0);  
# end;
# 
# if (nargin < 4) % Gabriel Graph ausrechnen
#     Gabriel = GabrielGraph(X,Y,Delaunay);
# end;
# 
# AnzCases =length(X);
# [AInd BInd] = find((Gabriel.*triu(ones(AnzCases,AnzCases)))>0); % AB indices
# 
# AnzPunkte=length(AInd);
# RNGraph = Gabriel ;              % aus dem gabriel werden kanten geloescht -> RNG
# for i=1:AnzPunkte
#     A = [X(AInd(i)),Y(AInd(i))]; % Punkt A
#     B = [X(BInd(i)),Y(BInd(i))]; % Punkt B
#     Radius = sqrt((B-A)*(B-A)');
#     Dist2A =  dist2all(A,[X,Y])';
#     InKreisAInd = find(((Dist2A-Radius) < 0.0001));  % nur die im Umkreis von A
#     Dist2B =  dist2all(B,[X(InKreisAInd),Y(InKreisAInd)])';
#     IstInLune = find((Dist2B-Radius) < 0.0001) ;
#     AnzInLune = length(IstInLune)-2 ; % 
#     if AnzInLune>0  % Kante Loeschen
#         RNGraph(AInd(i),BInd(i)) =0;
#         RNGraph(BInd(i),AInd(i)) =0;
#     end; % if AnzInLune>0  % Kante Loeschen
# end;% for i=1:AnzPunkte

 return ("The function RelativeNeighborhoodGraph is not implemented") 

 }

