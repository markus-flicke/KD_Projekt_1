nantozero <- function(z){

  out<-nantovalue(z,0)
  
 return (out) 

 }

