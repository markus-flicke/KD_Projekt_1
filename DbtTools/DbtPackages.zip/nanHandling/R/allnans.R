allnans <- function(x){

    n <-sum(is.na(x)) 
    
 return (n) 

 }

