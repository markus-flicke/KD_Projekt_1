nantonearest <- function(z,Data,defined=rep(1,dim(Data)[2])){

 n <- nantoknearest(z,1,Data,defined)
 return (n) 

 }

