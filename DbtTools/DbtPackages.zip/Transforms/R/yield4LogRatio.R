`yield4LogRatio` <-
function(logRatio){

	yield <- exp(logRatio)-1

 	return (yield) 

 }

