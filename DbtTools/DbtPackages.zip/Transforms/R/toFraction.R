`toFraction` <- function(data){

 scaled = toRange(data,0,1)
 return(scaled)

 }

