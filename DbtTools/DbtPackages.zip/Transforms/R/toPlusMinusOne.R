`toPlusMinusOne` <- function(x){

	scaled = toRange(x,-1,1);

	return(scaled)

 }

