norm2Derivation <- function(x){
 return ((1/sqrt(2*pi)*(x^2-1)*exp(-0.5*(x^2))))
}

