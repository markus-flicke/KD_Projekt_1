normDerivation <- function(x){
  return((-x/sqrt(2*pi))*exp(-0.5*(x^2)))
}