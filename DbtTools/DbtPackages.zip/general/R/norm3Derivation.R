norm3Derivation <- function(x){
  return((1/sqrt(2*pi)*(3*x-x^3)*exp(-0.5*(x^2))))
}

